# Paper


Here you can start writing your paper in markdown or RMarkdown ... or change this file when using another text processor.
