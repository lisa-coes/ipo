# IPO Ejemplo mínimo

Este es un ejemplo mínimo de un proyecto IPO. Se utilizan datos de la encuesta ELSOC para analizar percepción de meritocracia.
